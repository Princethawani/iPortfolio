README for Dany 2.01
Build 20001108

Dany was written by Jon Baer
jonbaer@digitalanywhere.com

What is Dany?

Dany is an AIML (Artificial Intelligence Language) browser that is capable of learning over over time.  It does this by input via the web or direct input through the application.  

Where did Dany come from?

Dany is a networked implementation of A.L.I.C.E. written by Dr. Richard Wallace.  You can find more information on AIML (Artificial Intelligence Language) and A.L.I.C.E. at http://www.alicebot.org.  

Why did you write Dany?

I wrote Dany as an experimentation to combine all the skills I had, from networking to speech synthesis to XML parsing and combing them all together.  Then I found A.L.I.C.E. and realized the true power of Natural Language Parsing (whether text input or spoken).  

If Hans Moravec and Ray Kurzweil report that by 2040 a $1000 computer will have enough brain power of a human what good is it if there is no protocol now for the machines to learn?  I think the machine is the greatest power because we are all slaves to the machine.  What are we always doing?  Feeding machines, everyone in the world right now is feeding some bit of information into the net @ a rate far exceeding expectations.  Designing a way to interact with that information (such as Alice,Dany, AIML) is amazing to me.

What platforms will Dany run on?

Currenly I am only testing on Win98/NT.  I am going to try to attempt one for Linux when I think its good enough.  

Will AIML replace HTML?

Maybe.  Things get adapted very quickly.  As many are now learning to write VoiceXML for voice interaction over the phone, the same could be said for the browser and appliances.  HTML is a "dumb" language, while AIML is "smart".  A bot could be trained to learn over time from other bots.

What technologies does Dany contain?

Right now it contains Java (with JNI for speech), JDOM (for XML parsing), Rhino (for Javascript), and Tomcat (for web serving).

Resources:
DANY - Official Site
http://www.digitalanywhere.com/projects/dany/index.html
A.L.I.C.E.
http://www.alicebot.org
AIML Reference
http://home.tampabay.rr.com/ringo/aimlrm.html
Java 
http://www.javasoft.com
JDOM
http://www.jdom.org
Jakarta Tomcat
http://jakarta.apache.org
http://www.javasoft.com
